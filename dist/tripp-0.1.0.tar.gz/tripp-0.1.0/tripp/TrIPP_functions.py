import MDAnalysis as mda 
import propka 
from propka import run
import numpy as np 
import os 
import multiprocessing as mp 
from edit_pdb import edit_pdb 
from edit_pdb import mutate 

class Trajectory: 

    def __init__(self, trajectory_file, topology_file, cpu_number): 

        self.trajectory_file = trajectory_file 
        self.topology_file = topology_file 
        self.cpu_number = cpu_number 
        self.universe = mda.Universe(self.topology_file, self.trajectory_file) 
        frames_nr = len(self.universe.trajectory) 
        slices_nr = self.cpu_number 
        slice_length = round(frames_nr/slices_nr) 
        slices = [] 
        start_frame = 0 
        end_frame = slice_length 
        for i in range(slices_nr): 
            if end_frame > frames_nr: 
                slices.append([start_frame, frames_nr]) 
            else: 
                slices.append([start_frame, end_frame]) 
            start_frame+=slice_length 
            end_frame+=slice_length 
        self.trajectory_slices = slices 
        

    def calculate_pka(self, output_file, extract_surface_data=False, chain='A', mutation=None, thread=None): 
        
        def extract_data(file, chain, time): 

            pkafile = open(file, 'r') 
            data_pka_list = [] 
            data_surf_list = [] 
            for line in pkafile: 
                line_processed = line.rstrip() 
                line_list = line_processed.strip().split() 
                if len(line_list) > 15 and line_list[2] == chain: 
                    data_pka_list.append([line_list[0]+line_list[1], line_list[3]]) 
                    data_surf_list.append([line_list[0]+line_list[1], line_list[4]]) 
            
            time_array = np.array([['Time [ps]'], [time]]) 
            data_pka_array = np.array(data_pka_list).T 
            data_pka = np.concatenate((time_array, data_pka_array), axis=1).tolist() 
            
            data_surf_array = np.array(data_surf_list).T 
            data_surf = np.concatenate((time_array, data_surf_array), axis=1).tolist() 
            
            return data_pka, data_surf

        def pka_iterator(thread): 
            
            start = self.trajectory_slices[thread][0] 
            end = self.trajectory_slices[thread][1]
            
            if type(mutation) == int: 
                out = f'{output_file}_{mutation}' 
                temp_name = f'temp_{mutation}_{thread}' 
            elif type(mutation) == list: 
                out = f'{output_file}_{"_".join(map(str, mutation))}' 
                temp_name = f'temp_{"_".join(map(str, mutation))}_{thread}' 
            else: 
                out = output_file 
                temp_name = f'temp_{thread}' 

            for index, ts in enumerate(self.universe.trajectory[start:end]):
                with mda.Writer(f'{temp_name}.pdb') as w: 
                    w.write(self.universe) 
                edit_pdb(f'{temp_name}.pdb')
                if mutation != None: 
                    mutate(temp_name, mutation) 
                run.single(f'{temp_name}.pdb')
                time = ts.time
                header = ','.join(extract_data(f'{temp_name}.pka', chain=chain, time=time)[0][0]) 
                data = ','.join(extract_data(f'{temp_name}.pka', chain=chain, time=time)[0][1]).replace('*', '')
                if index == 0 and thread == 0: 
                    f = open(f'{out}_pka.csv', "w")
                    f.write(header+'\n')
                    f.write(data+'\n')
                    f.close() 
                else: 
                    f = open(f'{out}_pka.csv', "a")
                    f.write(data+'\n')
                    f.close() 
                if extract_surface_data == True: 
                    header = ','.join(extract_data(f'{temp_name}.pka', chain=chain, time=time)[1][0]) 
                    data = ','.join(extract_data(f'{temp_name}.pka', chain=chain, time=time)[1][1]).replace('*', '') 
                    if index == 0 and thread == 0: 
                        f = open(f'{out}_surf.csv', "w")
                        f.write(header+'\n')
                        f.write(data+'\n')
                        f.close() 
                    else: 
                        f = open(f'{out}_surf.csv', "a")
                        f.write(data+'\n')
                        f.close() 
            
            os.remove(f'{temp_name}.pdb') 
            os.remove(f'{temp_name}.pka') 
        
        pka_iterator(thread) 

    
    def loop_function(self, output_file, index, extract_surface_data, chain, mutation): 
        self.calculate_pka(output_file, extract_surface_data=extract_surface_data, chain=chain, mutation=mutation, thread=index) 
    
    def run(self, output_file, extract_surface_data, chain, mutation): 
        if __name__ == '__main__':
            pool = mp.Pool(self.cpu_number)
            # Create jobs
            jobs = []
            for index, item in enumerate(self.trajectory_slices):
                # Create asynchronous jobs that will be submitted once a processor is ready
                job = pool.apply_async(self.loop_function, args=(output_file, index, extract_surface_data, chain, mutation,))
                jobs.append(job)
            # Submit jobs
            results = [job.get() for job in jobs]
            pool.close() 
